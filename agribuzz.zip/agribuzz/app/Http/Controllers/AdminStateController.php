<?php

namespace App\Http\Controllers;

use App\Models\admin_state;
use Illuminate\Http\Request;

class AdminStateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin/view');
    }

    public function create()
    {
        return view('admin/state/add');
    }

    public function store(Request $request)
    {
        $res=new admin_state;
		
		$res->state=$request->input('state');
		$res->save();
		
		$request->session()->flash('msg','data entered sucessfully');
		return redirect('admin/state/view');
    }

    public function show(admin_state $admin_state)
    {
        return view('admin/state/view')->with('s_arr',admin_state::all());
    }

    public function edit(admin_state $admin_state,$id)
    {
        return view('admin/state/edit')->with('s_arr',admin_state::find($id));
    }

    public function update(Request $request, admin_state $admin_state,$id)
    {
        $res=admin_state::find($request->id);
		
		$res->state=$request->input('state');
		$res->save();
		
		$request->session()->flash('msg','data updated sucessfully');
		return redirect('admin/state/view');
    }

    public function destroy(admin_state $admin_state,$id)
    {
        admin_state::destroy(array('id',$id));
		return redirect('admin/state/view');
    }
}
