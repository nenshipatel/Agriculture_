<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminloginContoller extends Controller
{
    function login_submit(Request $request)
	{
		echo $Email=$request->input('Email');
		echo $Password=$request->input('Password');
		
		$result=DB::table('_adminligin_tables')
		      ->where('Email',$Email)
			  ->where('Password',$Password)
			  ->get();
			  
			if(isset($request[0]->id))
			{
				if($result[0]->status==1)
				{
					$request->session()->put('Blog_user_id',$request[0]->id);
					return redirect('admin/state/view');
				}
				else
				{
			    $request->session()->flash('msg','Account diactivated');
				return redirect('admin/Adminlogin');	
				}
				
			}			
			else
			{
				$request->session()->flash('msg','please enter valid login details');
				//return redirect('admin/Adminlogin');
			}
		
	}
}
