<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminStateController;
use App\Http\Controllers\AdminloginContoller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::view('admin/Adminlogin', 'admin.Adminlogin');
Route::post('admin/login_submit', [AdminloginContoller::class,'login_submit']);
Route::view('admin/layout', 'admin.layout.layout');
Route::get('admin/state/add', [AdminStateController::class, 'create']);
Route::get('admin/state/view',[AdminStateController::class, 'show']);
Route::get('admin/state/edit/{id}',[AdminStateController::class, 'edit'])->name('agribuzz.edit');
Route::get('state_delete/{id}',[AdminStateController::class, 'destroy'])->name('agribuzz.delete');
Route::post('state_submit',[AdminStateController::class, 'store'])->name('agribuzz.insert');
Route::post('state_update/{id}',[AdminStateController::class, 'update'])->name('agribuzz.update');