
<?php $__env->startSection('container'); ?>

<div class="card-block">
     <h4 class="sub-title">Basic Inputs</h4>

		<form method="post" action="<?php echo e(route('agribuzz.update',[$s_arr->id])); ?>">
		<?php echo csrf_field(); ?>
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">State</label>
                <div class="col-sm-10">
				


			
                <input type="text" class="form-control" placeholder="State" name="state" value="<?php echo e($s_arr->state); ?>">
            </div>
            </div>
			 <button class="btn waves-effect waves-light btn-grd-success" value="submit">Submit</button> 
			 <button class="btn waves-effect waves-light btn-grd-info ">Cancel</button>
        </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\agribuzz\resources\views/admin/state/edit.blade.php ENDPATH**/ ?>