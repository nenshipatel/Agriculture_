
<?php $__env->startSection('container'); ?>
                                        <!-- Hover table card end -->
                                        <!-- Contextual classes table starts -->
                                        <div class="card">
                                            <div class="card-header">
                                                <h5>State</h5>
                                                <span></span>
                                                <div class="card-header-right">
                                                    <ul class="list-unstyled card-option">
                                                        <li><i class="fa fa fa-wrench open-card-option"></i></li>
                                                        <li><i class="fa fa-window-maximize full-card"></i></li>
                                                        <li><i class="fa fa-minus minimize-card"></i></li>
                                                        <li><i class="fa fa-refresh reload-card"></i></li>
                                                        <li><i class="fa fa-trash close-card"></i></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-block table-border-style">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
																
                                                                <th>Id</th>
                                                                <th>state</th>
																<th><i class="ti-trash"></i></th>
																<th><i class="ti-pencil"></i></th>
                                                                
                                                            </tr>
                                                        </thead>
                                                        <tbody>
															<?php $__currentLoopData = $s_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="">
                                                               
																<td><?php echo e($state->id); ?></td>
                                                                <td><?php echo e($state->state); ?></td>
                                                                <td><a href="<?php echo e(route('agribuzz.delete',[$state->id])); ?>"><i class="ti-trash"></i></a></td>
																<td><a href="<?php echo e(route('agribuzz.edit',[$state->id])); ?>"><i class="ti-pencil"</i></a></td>
                                                            </tr>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                           <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\agribuzz\resources\views/admin/state/view.blade.php ENDPATH**/ ?>