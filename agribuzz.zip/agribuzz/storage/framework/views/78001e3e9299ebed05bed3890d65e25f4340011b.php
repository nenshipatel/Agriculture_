<?php echo e(view('admin/header')); ?>

<?php echo e(view('admin/sidebar')); ?>




<?php echo e(view('admin/footer')); ?><?php /**PATH D:\laravel\agribuzz\resources\views/admin/dashbord.blade.php ENDPATH**/ ?>