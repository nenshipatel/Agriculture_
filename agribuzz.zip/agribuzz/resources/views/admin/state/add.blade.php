@extends('admin/layout.layout')
@section('container')

<div class="card-block">
     <h4 class="sub-title">Basic Inputs</h4>
		<form method="post" action="{{route('agribuzz.insert')}}">
		@csrf
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">State</label>
                <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="State" name="state">
            </div>
            </div>
			 <button class="btn waves-effect waves-light btn-grd-success" value="submit">Submit</button> 
			 <button class="btn waves-effect waves-light btn-grd-info ">Cancel</button>
        </form>
</div>


@endsection